from endstone_economy_pilot.main import (Main)

__all__ = ['Main']